using HealthTrackPro.Web.Services.Implementations;
using HealthTrackPro.Web.Services.Interfaces;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews(options => options.Filters.Add<HealthTrackPro.Web.Filters.TrainerExceptionFilter>());

// Cookie authentication. Maleesha's ASP.NET Identity replaces this on merge;
// the [Authorize(Roles = "Trainer")] attributes stay the same.
builder.Services.AddAuthentication("HealthTrackCookie")
    .AddCookie("HealthTrackCookie", options =>
    {
        options.LoginPath = "/DevAccount/SignIn";
        options.AccessDeniedPath = "/Account/AccessDenied";
    });
builder.Services.AddAuthorization();

// Development data store (seeded from the UI blueprint).
builder.Services.AddSingleton<InMemoryTrainerStore>();

// Trainer module services, registered against interfaces (dependency inversion).
builder.Services.AddScoped<IAssignedClientService, AssignedClientService>();
builder.Services.AddScoped<IAppointmentService, AppointmentService>();
builder.Services.AddScoped<IAvailabilityService, AvailabilityService>();
builder.Services.AddScoped<IFeedbackService, FeedbackService>();
builder.Services.AddScoped<IPlanAssignmentService, PlanAssignmentService>();
builder.Services.AddScoped<INotificationService, NotificationService>();
builder.Services.AddScoped<ITrainerDashboardService, TrainerDashboardService>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Account/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller=Dashboard}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=DevAccount}/{action=SignIn}/{id?}");

app.Run();
