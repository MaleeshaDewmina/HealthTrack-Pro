using HealthTrackPro.Web.Models.Enums;

namespace HealthTrackPro.Web.Models.Shared
{
    /// <summary>PLACEHOLDER for the shared Notification (owner: Maleesha).</summary>
    public class Notification
    {
        public int Id { get; set; }
        public string RecipientUserId { get; set; } = string.Empty;
        public NotificationType Type { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public bool IsRead { get; set; }
    }
}
