namespace HealthTrackPro.Web.Models.Shared
{
    /// <summary>
    /// PLACEHOLDER for the shared ClientProfile (owner: Maleesha).
    /// On merge, delete this file and use the shared class instead.
    /// </summary>
    public class ClientProfile
    {
        public int Id { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string Goal { get; set; } = string.Empty;
        public double WeightKg { get; set; }
        public double Bmi { get; set; }
        public int WorkoutCompletionPercent { get; set; }
        public int GoalProgressPercent { get; set; }
        public string AssignedTrainerId { get; set; } = string.Empty;
        public List<double> WeightHistory { get; set; } = new();
    }
}
