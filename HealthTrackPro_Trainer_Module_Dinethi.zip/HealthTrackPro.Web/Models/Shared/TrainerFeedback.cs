namespace HealthTrackPro.Web.Models.Shared
{
    /// <summary>PLACEHOLDER for the shared TrainerFeedback (owner: Maleesha).</summary>
    public class TrainerFeedback
    {
        public int Id { get; set; }
        public int ClientId { get; set; }
        public string TrainerId { get; set; } = string.Empty;
        public string RelatedArea { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public int Rating { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
