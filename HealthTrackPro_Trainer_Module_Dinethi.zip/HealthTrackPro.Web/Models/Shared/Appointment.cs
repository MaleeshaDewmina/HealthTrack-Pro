using HealthTrackPro.Web.Models.Enums;

namespace HealthTrackPro.Web.Models.Shared
{
    /// <summary>PLACEHOLDER for the shared Appointment (owner: Maleesha).</summary>
    public class Appointment
    {
        public int Id { get; set; }
        public int ClientId { get; set; }
        public string TrainerId { get; set; } = string.Empty;
        public DateTime StartsAt { get; set; }
        public int DurationMinutes { get; set; } = 60;
        public string Reason { get; set; } = string.Empty;
        public AppointmentStatus Status { get; set; } = AppointmentStatus.Pending;
    }
}
