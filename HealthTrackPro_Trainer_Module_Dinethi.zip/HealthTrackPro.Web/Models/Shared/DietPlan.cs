namespace HealthTrackPro.Web.Models.Shared
{
    /// <summary>PLACEHOLDER for DietPlan / Meal (owner: Maleesha).</summary>
    public class DietPlan
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int ClientId { get; set; }
        public string TrainerId { get; set; } = string.Empty;
        public int CalorieTarget { get; set; }
        public int ProteinGrams { get; set; }
        public int CarbsGrams { get; set; }
        public int FatGrams { get; set; }
        public List<Meal> Meals { get; set; } = new();
    }

    public class Meal
    {
        public string MealType { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public int Kcal { get; set; }
        public int ProteinGrams { get; set; }
    }
}
