namespace HealthTrackPro.Web.Models.Shared
{
    /// <summary>PLACEHOLDER for the shared TrainerAvailability (owner: Maleesha).</summary>
    public class TrainerAvailability
    {
        public int Id { get; set; }
        public string TrainerId { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public TimeSpan Start { get; set; }
        public TimeSpan End { get; set; }
        public bool IsOpen { get; set; } = true;
    }
}
