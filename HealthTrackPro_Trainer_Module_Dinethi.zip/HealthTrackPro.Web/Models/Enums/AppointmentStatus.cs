namespace HealthTrackPro.Web.Models.Enums
{
    /// <summary>Lifecycle of a client-trainer booking.</summary>
    public enum AppointmentStatus
    {
        Pending,
        Approved,
        Rejected,
        Cancelled,
        Completed
    }
}
