namespace HealthTrackPro.Web.Models.Enums
{
    public enum NotificationType
    {
        NewAppointment,
        AppointmentUpdate,
        ClientMilestone,
        PlanReview,
        NewFeedback,
        Reminder
    }
}
