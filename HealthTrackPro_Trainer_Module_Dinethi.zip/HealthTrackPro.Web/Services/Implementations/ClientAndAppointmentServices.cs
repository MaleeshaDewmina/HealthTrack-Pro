using HealthTrackPro.Web.Models.Enums;
using HealthTrackPro.Web.Models.Shared;
using HealthTrackPro.Web.Services.Exceptions;
using HealthTrackPro.Web.Services.Interfaces;

namespace HealthTrackPro.Web.Services.Implementations
{
    public sealed class AssignedClientService : IAssignedClientService
    {
        private readonly InMemoryTrainerStore _store;
        public AssignedClientService(InMemoryTrainerStore store) => _store = store;

        public IReadOnlyList<ClientProfile> GetAssignedClients(string trainerId, string? search = null)
        {
            lock (_store.Gate)
            {
                var query = _store.Clients.Where(c => c.AssignedTrainerId == trainerId);
                if (!string.IsNullOrWhiteSpace(search))
                {
                    query = query.Where(c => c.FullName.Contains(search.Trim(), StringComparison.OrdinalIgnoreCase)
                                          || c.Goal.Contains(search.Trim(), StringComparison.OrdinalIgnoreCase));
                }
                return query.OrderBy(c => c.FullName).ToList();
            }
        }

        public ClientProfile GetAssignedClient(string trainerId, int clientId)
        {
            lock (_store.Gate)
            {
                var client = _store.Clients.FirstOrDefault(c => c.Id == clientId)
                    ?? throw new TrainerNotFoundException($"Client #{clientId} was not found.");
                if (client.AssignedTrainerId != trainerId)
                    throw new TrainerForbiddenException("This client is not assigned to you.");
                return client;
            }
        }
    }

    public sealed class AppointmentService : IAppointmentService
    {
        private readonly InMemoryTrainerStore _store;
        public AppointmentService(InMemoryTrainerStore store) => _store = store;

        public IReadOnlyList<Appointment> GetForTrainer(string trainerId)
        {
            lock (_store.Gate)
                return _store.Appointments.Where(a => a.TrainerId == trainerId).OrderBy(a => a.StartsAt).ToList();
        }

        public IReadOnlyList<Appointment> GetTodayForTrainer(string trainerId, DateTime today)
        {
            lock (_store.Gate)
                return _store.Appointments
                    .Where(a => a.TrainerId == trainerId && a.StartsAt.Date == today.Date
                                && a.Status is AppointmentStatus.Pending or AppointmentStatus.Approved)
                    .OrderBy(a => a.StartsAt).ToList();
        }

        public Appointment Approve(string trainerId, int appointmentId)
        {
            lock (_store.Gate)
            {
                var appt = FindOwned(trainerId, appointmentId);
                if (appt.Status != AppointmentStatus.Pending)
                    throw new TrainerRuleViolationException($"Only pending appointments can be approved (current status: {appt.Status}).");
                appt.Status = AppointmentStatus.Approved;
                NotifyClient(appt, NotificationType.AppointmentUpdate, "Appointment approved", "Your trainer approved your consultation.");
                return appt;
            }
        }

        public Appointment Reject(string trainerId, int appointmentId)
        {
            lock (_store.Gate)
            {
                var appt = FindOwned(trainerId, appointmentId);
                if (appt.Status != AppointmentStatus.Pending)
                    throw new TrainerRuleViolationException($"Only pending appointments can be rejected (current status: {appt.Status}).");
                appt.Status = AppointmentStatus.Rejected;
                NotifyClient(appt, NotificationType.AppointmentUpdate, "Appointment declined", "Your trainer could not accept this time.");
                return appt;
            }
        }

        public Appointment Cancel(string trainerId, int appointmentId)
        {
            lock (_store.Gate)
            {
                var appt = FindOwned(trainerId, appointmentId);
                if (appt.Status is AppointmentStatus.Completed or AppointmentStatus.Cancelled or AppointmentStatus.Rejected)
                    throw new TrainerRuleViolationException($"A {appt.Status.ToString().ToLowerInvariant()} appointment cannot be cancelled.");
                appt.Status = AppointmentStatus.Cancelled;
                NotifyClient(appt, NotificationType.AppointmentUpdate, "Appointment cancelled", "Your trainer cancelled an appointment.");
                return appt;
            }
        }

        private Appointment FindOwned(string trainerId, int appointmentId)
        {
            var appt = _store.Appointments.FirstOrDefault(a => a.Id == appointmentId)
                ?? throw new TrainerNotFoundException($"Appointment #{appointmentId} was not found.");
            if (appt.TrainerId != trainerId)
                throw new TrainerForbiddenException("This appointment belongs to another trainer.");
            return appt;
        }

        // Stand-in for the shared notification service; Maleesha's version replaces this on merge.
        private void NotifyClient(Appointment appt, NotificationType type, string title, string body)
        {
            _store.Notifications.Add(new Notification
            {
                Id = _store.NextId(), RecipientUserId = appt.ClientId.ToString(), Type = type,
                Title = title, Body = body, CreatedAt = DateTime.Now
            });
        }
    }

    public sealed class AvailabilityService : IAvailabilityService
    {
        private readonly InMemoryTrainerStore _store;
        public AvailabilityService(InMemoryTrainerStore store) => _store = store;

        public IReadOnlyList<TrainerAvailability> GetForTrainer(string trainerId)
        {
            lock (_store.Gate)
                return _store.Availability.Where(s => s.TrainerId == trainerId)
                    .OrderBy(s => s.Date).ThenBy(s => s.Start).ToList();
        }

        public TrainerAvailability AddSlot(string trainerId, DateTime date, TimeSpan start, TimeSpan end)
        {
            if (end <= start)
                throw new TrainerRuleViolationException("The end time must be after the start time.");
            if (date.Date < DateTime.Today)
                throw new TrainerRuleViolationException("Availability cannot be added for a past date.");

            lock (_store.Gate)
            {
                bool overlaps = _store.Availability.Any(s =>
                    s.TrainerId == trainerId && s.Date.Date == date.Date && s.Start < end && start < s.End);
                if (overlaps)
                    throw new TrainerRuleViolationException("This time overlaps an existing availability slot.");

                var slot = new TrainerAvailability
                {
                    Id = _store.NextId(), TrainerId = trainerId, Date = date.Date,
                    Start = start, End = end, IsOpen = true
                };
                _store.Availability.Add(slot);
                return slot;
            }
        }

        public void RemoveSlot(string trainerId, int slotId)
        {
            lock (_store.Gate)
            {
                var slot = _store.Availability.FirstOrDefault(s => s.Id == slotId)
                    ?? throw new TrainerNotFoundException($"Availability slot #{slotId} was not found.");
                if (slot.TrainerId != trainerId)
                    throw new TrainerForbiddenException("This availability slot belongs to another trainer.");
                _store.Availability.Remove(slot);
            }
        }
    }
}
