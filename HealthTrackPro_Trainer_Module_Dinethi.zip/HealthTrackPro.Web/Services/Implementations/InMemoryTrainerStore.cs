using HealthTrackPro.Web.Models.Enums;
using HealthTrackPro.Web.Models.Shared;

namespace HealthTrackPro.Web.Services.Implementations
{
    /// <summary>
    /// Development data store used until the shared EF Core DbContext is merged in.
    /// Seeded from the UI blueprint. Thread-safe enough for a single-user demo (lock on every access).
    /// </summary>
    public sealed class InMemoryTrainerStore
    {
        /// <summary>Dinethi's trainer account id (matches the dev sign-in).</summary>
        public const string DinethiTrainerId = "dinethi";
        public const string OtherTrainerId = "nperera";

        private readonly object _gate = new();
        public List<ClientProfile> Clients { get; } = new();
        public List<Appointment> Appointments { get; } = new();
        public List<TrainerAvailability> Availability { get; } = new();
        public List<TrainerFeedback> Feedback { get; } = new();
        public List<WorkoutPlan> WorkoutPlans { get; } = new();
        public List<DietPlan> DietPlans { get; } = new();
        public List<Notification> Notifications { get; } = new();

        private int _nextId = 100;
        public int NextId() { lock (_gate) return _nextId++; }
        public object Gate => _gate;

        public InMemoryTrainerStore()
        {
            var today = DateTime.Today;

            Clients.AddRange(new[]
            {
                new ClientProfile { Id = 1, FullName = "Alex Silva",   Goal = "Lose Weight", WeightKg = 72.4, Bmi = 22.4, WorkoutCompletionPercent = 82, GoalProgressPercent = 78, AssignedTrainerId = DinethiTrainerId, WeightHistory = new() { 75.0, 74.1, 73.6, 73.0, 72.8, 72.4 } },
                new ClientProfile { Id = 2, FullName = "Nimal Perera", Goal = "Gain Muscle", WeightKg = 68.0, Bmi = 23.1, WorkoutCompletionPercent = 70, GoalProgressPercent = 65, AssignedTrainerId = DinethiTrainerId, WeightHistory = new() { 75.0, 74.1, 73.6, 73.0, 72.8, 72.4 } },
                new ClientProfile { Id = 3, FullName = "Kavindi Silva", Goal = "Fitness",    WeightKg = 58.2, Bmi = 21.0, WorkoutCompletionPercent = 90, GoalProgressPercent = 82, AssignedTrainerId = DinethiTrainerId, WeightHistory = new() { 75.0, 74.1, 73.6, 73.0, 72.8, 72.4 } },
                new ClientProfile { Id = 4, FullName = "Ruwan Dias",   Goal = "Strength",    WeightKg = 80.5, Bmi = 25.2, WorkoutCompletionPercent = 60, GoalProgressPercent = 48, AssignedTrainerId = DinethiTrainerId, WeightHistory = new() { 75.0, 74.1, 73.6, 73.0, 72.8, 72.4 } },
                // Belongs to another trainer: used to prove ownership checks block access.
                new ClientProfile { Id = 5, FullName = "Sahan Fernando", Goal = "Cardio",    WeightKg = 75.0, Bmi = 24.0, WorkoutCompletionPercent = 55, GoalProgressPercent = 40, AssignedTrainerId = OtherTrainerId }
            });

            Appointments.AddRange(new[]
            {
                new Appointment { Id = 1, ClientId = 1, TrainerId = DinethiTrainerId, StartsAt = today.AddHours(16.5), Reason = "Progress consultation", Status = AppointmentStatus.Pending },
                new Appointment { Id = 2, ClientId = 2, TrainerId = DinethiTrainerId, StartsAt = today.AddHours(17.5), Reason = "Strength review",      Status = AppointmentStatus.Approved },
                new Appointment { Id = 3, ClientId = 3, TrainerId = DinethiTrainerId, StartsAt = today.AddDays(1).AddHours(15), Reason = "Diet check-in", Status = AppointmentStatus.Pending },
                new Appointment { Id = 4, ClientId = 4, TrainerId = DinethiTrainerId, StartsAt = today.AddDays(-3).AddHours(10), Reason = "Initial assessment", Status = AppointmentStatus.Completed },
                new Appointment { Id = 5, ClientId = 5, TrainerId = OtherTrainerId,   StartsAt = today.AddDays(1).AddHours(11), Reason = "Cardio plan", Status = AppointmentStatus.Pending }
            });

            Availability.AddRange(new[]
            {
                new TrainerAvailability { Id = 1, TrainerId = DinethiTrainerId, Date = today.AddDays(1), Start = new TimeSpan(16, 0, 0), End = new TimeSpan(18, 0, 0), IsOpen = true },
                new TrainerAvailability { Id = 2, TrainerId = DinethiTrainerId, Date = today.AddDays(2), Start = new TimeSpan(15, 0, 0), End = new TimeSpan(17, 0, 0), IsOpen = true }
            });

            Feedback.Add(new TrainerFeedback { Id = 1, ClientId = 1, TrainerId = DinethiTrainerId, RelatedArea = "Workout", Message = "Great consistency this week.", Rating = 4, CreatedAt = today.AddDays(-1) });

            WorkoutPlans.Add(new WorkoutPlan
            {
                Id = 1, Name = "Upper Body Strength", ClientId = 1, TrainerId = DinethiTrainerId,
                StartDate = today, EndDate = today.AddDays(30),
                Exercises = new List<WorkoutExercise>
                {
                    new() { Name = "Bench Press",     Sets = 4, Reps = 10, RestSeconds = 90 },
                    new() { Name = "Seated Row",      Sets = 4, Reps = 12, RestSeconds = 60 },
                    new() { Name = "Shoulder Press",  Sets = 3, Reps = 10, RestSeconds = 60 }
                }
            });

            DietPlans.Add(new DietPlan
            {
                Id = 1, Name = "Balanced Fat Loss", ClientId = 1, TrainerId = DinethiTrainerId,
                CalorieTarget = 2100, ProteinGrams = 150, CarbsGrams = 220, FatGrams = 65,
                Meals = new List<Meal>
                {
                    new() { MealType = "Breakfast", Name = "Oats + Eggs",   Kcal = 480, ProteinGrams = 28 },
                    new() { MealType = "Lunch",     Name = "Chicken Rice",  Kcal = 620, ProteinGrams = 45 },
                    new() { MealType = "Dinner",    Name = "Fish + Salad",  Kcal = 560, ProteinGrams = 42 }
                }
            });

            Notifications.AddRange(new[]
            {
                new Notification { Id = 1, RecipientUserId = DinethiTrainerId, Type = NotificationType.NewAppointment, Title = "New appointment", Body = "Alex Silva requested a consultation today at 4:30 PM.", CreatedAt = today.AddHours(9) },
                new Notification { Id = 2, RecipientUserId = DinethiTrainerId, Type = NotificationType.ClientMilestone, Title = "Client milestone", Body = "Kavindi Silva reached 80% of her goal.", CreatedAt = today.AddHours(8) },
                new Notification { Id = 3, RecipientUserId = DinethiTrainerId, Type = NotificationType.PlanReview, Title = "Plan review", Body = "Nimal Perera's workout plan ends in 3 days.", CreatedAt = today.AddHours(7) }
            });
        }
    }
}
