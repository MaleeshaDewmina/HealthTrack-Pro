using HealthTrackPro.Web.Models.Enums;
using HealthTrackPro.Web.Models.Shared;
using HealthTrackPro.Web.Services.Exceptions;
using HealthTrackPro.Web.Services.Interfaces;

namespace HealthTrackPro.Web.Services.Implementations
{
    public sealed class FeedbackService : IFeedbackService
    {
        private readonly InMemoryTrainerStore _store;
        private readonly IAssignedClientService _clients; // reuse ownership rule, do not duplicate it

        public FeedbackService(InMemoryTrainerStore store, IAssignedClientService clients)
        {
            _store = store;
            _clients = clients;
        }

        public IReadOnlyList<TrainerFeedback> GetForTrainer(string trainerId)
        {
            lock (_store.Gate)
                return _store.Feedback.Where(f => f.TrainerId == trainerId).OrderByDescending(f => f.CreatedAt).ToList();
        }

        public TrainerFeedback Add(string trainerId, int clientId, string relatedArea, string message, int rating)
        {
            _clients.GetAssignedClient(trainerId, clientId); // throws if not assigned
            if (rating < 1 || rating > 5)
                throw new TrainerRuleViolationException("Rating must be between 1 and 5.");

            lock (_store.Gate)
            {
                var feedback = new TrainerFeedback
                {
                    Id = _store.NextId(), ClientId = clientId, TrainerId = trainerId,
                    RelatedArea = relatedArea, Message = message.Trim(), Rating = rating, CreatedAt = DateTime.Now
                };
                _store.Feedback.Add(feedback);
                _store.Notifications.Add(new Notification
                {
                    Id = _store.NextId(), RecipientUserId = clientId.ToString(), Type = NotificationType.NewFeedback,
                    Title = "New feedback", Body = "Your trainer added feedback to your weekly review.", CreatedAt = DateTime.Now
                });
                return feedback;
            }
        }
    }

    public sealed class PlanAssignmentService : IPlanAssignmentService
    {
        private readonly InMemoryTrainerStore _store;
        private readonly IAssignedClientService _clients;

        public PlanAssignmentService(InMemoryTrainerStore store, IAssignedClientService clients)
        {
            _store = store;
            _clients = clients;
        }

        public IReadOnlyList<WorkoutPlan> GetWorkoutPlans(string trainerId)
        {
            lock (_store.Gate) return _store.WorkoutPlans.Where(p => p.TrainerId == trainerId).ToList();
        }

        public IReadOnlyList<DietPlan> GetDietPlans(string trainerId)
        {
            lock (_store.Gate) return _store.DietPlans.Where(p => p.TrainerId == trainerId).ToList();
        }

        public WorkoutPlan AssignWorkout(string trainerId, int clientId, string planName, DateTime start, DateTime end, IEnumerable<WorkoutExercise> exercises)
        {
            _clients.GetAssignedClient(trainerId, clientId);
            var list = exercises.Where(e => !string.IsNullOrWhiteSpace(e.Name)).ToList();
            if (list.Count == 0) throw new TrainerRuleViolationException("A workout plan needs at least one exercise.");
            if (end < start) throw new TrainerRuleViolationException("The end date cannot be before the start date.");

            lock (_store.Gate)
            {
                var plan = new WorkoutPlan
                {
                    Id = _store.NextId(), Name = planName.Trim(), ClientId = clientId, TrainerId = trainerId,
                    StartDate = start, EndDate = end, Exercises = list
                };
                _store.WorkoutPlans.Add(plan);
                NotifyClient(clientId, NotificationType.PlanReview, "New workout plan", $"{plan.Name} is ready to start.");
                return plan;
            }
        }

        public DietPlan AssignDiet(string trainerId, int clientId, string planName, int calories, int protein, int carbs, int fat, IEnumerable<Meal> meals)
        {
            _clients.GetAssignedClient(trainerId, clientId);
            if (calories <= 0 || protein < 0 || carbs < 0 || fat < 0)
                throw new TrainerRuleViolationException("Calories must be positive and macros cannot be negative.");
            var list = meals.Where(m => !string.IsNullOrWhiteSpace(m.Name)).ToList();
            if (list.Count == 0) throw new TrainerRuleViolationException("A diet plan needs at least one meal.");

            lock (_store.Gate)
            {
                var plan = new DietPlan
                {
                    Id = _store.NextId(), Name = planName.Trim(), ClientId = clientId, TrainerId = trainerId,
                    CalorieTarget = calories, ProteinGrams = protein, CarbsGrams = carbs, FatGrams = fat, Meals = list
                };
                _store.DietPlans.Add(plan);
                NotifyClient(clientId, NotificationType.Reminder, "New diet plan", $"{plan.Name} has been assigned.");
                return plan;
            }
        }

        private void NotifyClient(int clientId, NotificationType type, string title, string body)
        {
            _store.Notifications.Add(new Notification
            {
                Id = _store.NextId(), RecipientUserId = clientId.ToString(), Type = type,
                Title = title, Body = body, CreatedAt = DateTime.Now
            });
        }
    }

    public sealed class NotificationService : INotificationService
    {
        private readonly InMemoryTrainerStore _store;
        public NotificationService(InMemoryTrainerStore store) => _store = store;

        public IReadOnlyList<Notification> GetForUser(string userId)
        {
            lock (_store.Gate)
                return _store.Notifications.Where(n => n.RecipientUserId == userId)
                    .OrderByDescending(n => n.CreatedAt).ToList();
        }

        public void MarkRead(string userId, int notificationId)
        {
            lock (_store.Gate)
            {
                var n = _store.Notifications.FirstOrDefault(x => x.Id == notificationId)
                    ?? throw new TrainerNotFoundException($"Notification #{notificationId} was not found.");
                if (n.RecipientUserId != userId)
                    throw new TrainerForbiddenException("You cannot change another user's notification.");
                n.IsRead = true;
            }
        }
    }

    /// <summary>Composition: the dashboard is built from several services, not one giant query.</summary>
    public sealed class TrainerDashboardService : ITrainerDashboardService
    {
        private readonly IAssignedClientService _clients;
        private readonly IAppointmentService _appointments;
        private readonly INotificationService _notifications;
        private readonly InMemoryTrainerStore _store;

        public TrainerDashboardService(IAssignedClientService clients, IAppointmentService appointments,
                                       INotificationService notifications, InMemoryTrainerStore store)
        {
            _clients = clients;
            _appointments = appointments;
            _notifications = notifications;
            _store = store;
        }

        public TrainerDashboardSummary Build(string trainerId, DateTime today)
        {
            var clients = _clients.GetAssignedClients(trainerId);
            var todays = _appointments.GetTodayForTrainer(trainerId, today);
            var recent = _notifications.GetForUser(trainerId).Take(5).ToList();

            int plansDue;
            lock (_store.Gate)
                plansDue = _store.WorkoutPlans.Count(p => p.TrainerId == trainerId && p.EndDate <= today.AddDays(3));

            int avg = clients.Count == 0 ? 0 : (int)Math.Round(clients.Average(c => c.GoalProgressPercent));
            return new TrainerDashboardSummary(clients.Count, todays.Count, plansDue, avg, clients, todays, recent);
        }
    }
}
