using HealthTrackPro.Web.Models.Shared;

namespace HealthTrackPro.Web.Services.Interfaces
{
    /// <summary>Clients assigned to a trainer. Every method is scoped to one trainer.</summary>
    public interface IAssignedClientService
    {
        IReadOnlyList<ClientProfile> GetAssignedClients(string trainerId, string? search = null);
        /// <summary>Throws TrainerForbiddenException if the client is not assigned to this trainer.</summary>
        ClientProfile GetAssignedClient(string trainerId, int clientId);
    }

    /// <summary>Appointment list, approval and cancellation for one trainer.</summary>
    public interface IAppointmentService
    {
        IReadOnlyList<Appointment> GetForTrainer(string trainerId);
        IReadOnlyList<Appointment> GetTodayForTrainer(string trainerId, DateTime today);
        Appointment Approve(string trainerId, int appointmentId);
        Appointment Reject(string trainerId, int appointmentId);
        Appointment Cancel(string trainerId, int appointmentId);
    }

    /// <summary>Time ranges the trainer offers for client bookings.</summary>
    public interface IAvailabilityService
    {
        IReadOnlyList<TrainerAvailability> GetForTrainer(string trainerId);
        TrainerAvailability AddSlot(string trainerId, DateTime date, TimeSpan start, TimeSpan end);
        void RemoveSlot(string trainerId, int slotId);
    }

    /// <summary>Feedback a trainer writes about a client's progress.</summary>
    public interface IFeedbackService
    {
        IReadOnlyList<TrainerFeedback> GetForTrainer(string trainerId);
        TrainerFeedback Add(string trainerId, int clientId, string relatedArea, string message, int rating);
    }

    /// <summary>Workout and diet assignments created by a trainer for an assigned client.</summary>
    public interface IPlanAssignmentService
    {
        IReadOnlyList<WorkoutPlan> GetWorkoutPlans(string trainerId);
        IReadOnlyList<DietPlan> GetDietPlans(string trainerId);
        WorkoutPlan AssignWorkout(string trainerId, int clientId, string planName, DateTime start, DateTime end, IEnumerable<WorkoutExercise> exercises);
        DietPlan AssignDiet(string trainerId, int clientId, string planName, int calories, int protein, int carbs, int fat, IEnumerable<Meal> meals);
    }

    /// <summary>In-app notifications for the trainer.</summary>
    public interface INotificationService
    {
        IReadOnlyList<Notification> GetForUser(string userId);
        void MarkRead(string userId, int notificationId);
    }

    /// <summary>Composes results from several services into the dashboard view model.</summary>
    public interface ITrainerDashboardService
    {
        TrainerDashboardSummary Build(string trainerId, DateTime today);
    }

    public sealed record TrainerDashboardSummary(
        int AssignedClientCount,
        int TodayAppointmentCount,
        int PlansDueForReview,
        int AverageProgressPercent,
        IReadOnlyList<ClientProfile> ClientRows,
        IReadOnlyList<Appointment> UpcomingToday,
        IReadOnlyList<Notification> RecentNotifications);
}
