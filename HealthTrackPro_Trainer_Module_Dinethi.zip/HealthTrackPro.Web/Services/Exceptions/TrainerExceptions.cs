namespace HealthTrackPro.Web.Services.Exceptions
{
    /// <summary>Base type for expected, user-facing trainer errors.</summary>
    public class TrainerDomainException : Exception
    {
        public TrainerDomainException(string message) : base(message) { }
    }

    /// <summary>The requested record does not exist (or the ID is invalid).</summary>
    public class TrainerNotFoundException : TrainerDomainException
    {
        public TrainerNotFoundException(string message) : base(message) { }
    }

    /// <summary>The trainer tried to act on a client or record they are not assigned to.</summary>
    public class TrainerForbiddenException : TrainerDomainException
    {
        public TrainerForbiddenException(string message) : base(message) { }
    }

    /// <summary>A business rule was broken, e.g. approving a cancelled appointment.</summary>
    public class TrainerRuleViolationException : TrainerDomainException
    {
        public TrainerRuleViolationException(string message) : base(message) { }
    }
}
