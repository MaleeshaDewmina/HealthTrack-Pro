using System.ComponentModel.DataAnnotations;

namespace HealthTrackPro.Web.Areas.Trainer.Models
{
    /// <summary>Dashboard screen data (composed by TrainerDashboardService).</summary>
    public sealed class TrainerDashboardViewModel
    {
        public int AssignedClients { get; init; }
        public int TodayAppointments { get; init; }
        public int PlansDue { get; init; }
        public int AverageProgress { get; init; }
        public IReadOnlyList<ClientRowViewModel> ClientRows { get; init; } = Array.Empty<ClientRowViewModel>();
        public IReadOnlyList<UpcomingItemViewModel> Upcoming { get; init; } = Array.Empty<UpcomingItemViewModel>();
        public IReadOnlyList<NotificationItemViewModel> Notifications { get; init; } = Array.Empty<NotificationItemViewModel>();
    }

    public sealed class ClientRowViewModel
    {
        public int Id { get; init; }
        public string Name { get; init; } = string.Empty;
        public string Goal { get; init; } = string.Empty;
        public int ProgressPercent { get; init; }

        public static ClientRowViewModel From(HealthTrackPro.Web.Models.Shared.ClientProfile c) => new()
        {
            Id = c.Id,
            Name = c.FullName,
            Goal = c.Goal,
            ProgressPercent = c.GoalProgressPercent
        };
    }

    public sealed class UpcomingItemViewModel
    {
        public int AppointmentId { get; init; }
        public string Time { get; init; } = string.Empty;
        public string ClientName { get; init; } = string.Empty;
        public string Status { get; init; } = string.Empty;
    }

    public sealed class NotificationItemViewModel
    {
        public int Id { get; init; }
        public string Title { get; init; } = string.Empty;
        public string Body { get; init; } = string.Empty;
        public string When { get; init; } = string.Empty;
        public string Accent { get; init; } = "green";
    }

    public sealed class AssignedClientsViewModel
    {
        public string? Search { get; init; }
        public IReadOnlyList<ClientRowViewModel> Clients { get; init; } = Array.Empty<ClientRowViewModel>();
    }

    public sealed class ClientDetailsViewModel
    {
        public int Id { get; init; }
        public string Name { get; init; } = string.Empty;
        public string Goal { get; init; } = string.Empty;
        public double WeightKg { get; init; }
        public double Bmi { get; init; }
        public int WorkoutCompletion { get; init; }
        public int GoalProgress { get; init; }
        public IReadOnlyList<double> RecentProgress { get; init; } = Array.Empty<double>();
    }

    /// <summary>Form: assign a workout plan. Validated here and again in the service.</summary>
    public sealed class AssignWorkoutViewModel
    {
        [Required(ErrorMessage = "Choose a client.")]
        public int ClientId { get; set; }

        [Required(ErrorMessage = "Enter a plan name.")]
        [StringLength(80, ErrorMessage = "Plan name must be 80 characters or fewer.")]
        public string PlanName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Pick a start date.")]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; } = DateTime.Today;

        [Required(ErrorMessage = "Pick an end date.")]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; } = DateTime.Today.AddDays(30);

        public List<ExerciseRowViewModel> Exercises { get; set; } = new()
        {
            new() { Name = "Bench Press", Sets = 4, Reps = 10, RestSeconds = 90 },
            new() { Name = "Seated Row", Sets = 4, Reps = 12, RestSeconds = 60 },
            new() { Name = "Shoulder Press", Sets = 3, Reps = 10, RestSeconds = 60 }
        };
    }

    public sealed class ExerciseRowViewModel
    {
        [StringLength(60)]
        public string Name { get; set; } = string.Empty;

        [Range(1, 20, ErrorMessage = "Sets must be 1 to 20.")]
        public int Sets { get; set; } = 3;

        [Range(1, 100, ErrorMessage = "Reps must be 1 to 100.")]
        public int Reps { get; set; } = 10;

        [Range(0, 600, ErrorMessage = "Rest must be 0 to 600 seconds.")]
        public int RestSeconds { get; set; } = 60;
    }

    /// <summary>Form: assign a diet plan with macros and meals.</summary>
    public sealed class AssignDietViewModel
    {
        [Required(ErrorMessage = "Choose a client.")]
        public int ClientId { get; set; }

        [Required(ErrorMessage = "Enter a plan name.")]
        [StringLength(80)]
        public string PlanName { get; set; } = string.Empty;

        [Range(800, 6000, ErrorMessage = "Calorie target must be 800 to 6000 kcal.")]
        public int CalorieTarget { get; set; } = 2100;

        [Range(0, 400, ErrorMessage = "Protein must be 0 to 400 g.")]
        public int ProteinGrams { get; set; } = 150;

        [Range(0, 600, ErrorMessage = "Carbs must be 0 to 600 g.")]
        public int CarbsGrams { get; set; } = 220;

        [Range(0, 300, ErrorMessage = "Fat must be 0 to 300 g.")]
        public int FatGrams { get; set; } = 65;

        public List<MealRowViewModel> Meals { get; set; } = new()
        {
            new() { MealType = "Breakfast", Name = "Oats + Eggs", Kcal = 480, ProteinGrams = 28 },
            new() { MealType = "Lunch", Name = "Chicken Rice", Kcal = 620, ProteinGrams = 45 },
            new() { MealType = "Dinner", Name = "Fish + Salad", Kcal = 560, ProteinGrams = 42 }
        };
    }

    public sealed class MealRowViewModel
    {
        [StringLength(20)]
        public string MealType { get; set; } = string.Empty;

        [StringLength(60)]
        public string Name { get; set; } = string.Empty;

        [Range(0, 3000, ErrorMessage = "Kcal must be 0 to 3000.")]
        public int Kcal { get; set; }

        [Range(0, 300, ErrorMessage = "Protein must be 0 to 300 g.")]
        public int ProteinGrams { get; set; }
    }

    /// <summary>Form: add an availability slot.</summary>
    public sealed class AvailabilityCreateViewModel
    {
        [Required(ErrorMessage = "Pick a date.")]
        [DataType(DataType.Date)]
        public DateTime Date { get; set; } = DateTime.Today.AddDays(1);

        [Required(ErrorMessage = "Pick a start time.")]
        [DataType(DataType.Time)]
        public TimeSpan Start { get; set; } = new(16, 0, 0);

        [Required(ErrorMessage = "Pick an end time.")]
        [DataType(DataType.Time)]
        public TimeSpan End { get; set; } = new(18, 0, 0);
    }

    /// <summary>Form: write feedback for an assigned client.</summary>
    public sealed class FeedbackCreateViewModel
    {
        [Required(ErrorMessage = "Choose a client.")]
        public int ClientId { get; set; }

        [Required(ErrorMessage = "Choose the related area.")]
        [StringLength(30)]
        public string RelatedArea { get; set; } = "Workout";

        [Required(ErrorMessage = "Write a short message.")]
        [StringLength(500, MinimumLength = 5, ErrorMessage = "Message must be 5 to 500 characters.")]
        public string Message { get; set; } = string.Empty;

        [Range(1, 5, ErrorMessage = "Rating must be 1 to 5.")]
        public int Rating { get; set; } = 4;
    }

    public sealed class AppointmentRowViewModel
    {
        public int Id { get; init; }
        public string ClientName { get; init; } = string.Empty;
        public string When { get; init; } = string.Empty;
        public string Reason { get; init; } = string.Empty;
        public string Status { get; init; } = string.Empty;
        public bool CanDecide { get; init; }   // Pending only
        public bool CanCancel { get; init; }   // Pending or Approved
    }

    public sealed class AvailabilityRowViewModel
    {
        public int Id { get; init; }
        public string Date { get; init; } = string.Empty;
        public string Range { get; init; } = string.Empty;
        public string Status { get; init; } = string.Empty;
    }

    public sealed class FeedbackRowViewModel
    {
        public string ClientName { get; init; } = string.Empty;
        public string RelatedArea { get; init; } = string.Empty;
        public string Message { get; init; } = string.Empty;
        public int Rating { get; init; }
        public string When { get; init; } = string.Empty;
    }

    public sealed class PlansOverviewViewModel
    {
        public IReadOnlyList<PlanRowViewModel> Workouts { get; init; } = Array.Empty<PlanRowViewModel>();
        public IReadOnlyList<PlanRowViewModel> Diets { get; init; } = Array.Empty<PlanRowViewModel>();
    }

    public sealed class PlanRowViewModel
    {
        public string ClientName { get; init; } = string.Empty;
        public string PlanName { get; init; } = string.Empty;
        public string Detail { get; init; } = string.Empty;
    }
}
