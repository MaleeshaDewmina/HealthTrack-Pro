using HealthTrackPro.Web.Areas.Trainer.Models;
using HealthTrackPro.Web.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace HealthTrackPro.Web.Areas.Trainer.Controllers
{
    public class FeedbackController : TrainerControllerBase
    {
        private readonly IFeedbackService _feedback;
        private readonly IAssignedClientService _clients;

        public FeedbackController(IFeedbackService feedback, IAssignedClientService clients)
        {
            _feedback = feedback;
            _clients = clients;
        }

        public IActionResult Index() => View(new FeedbackPageViewModel(Rows(), new FeedbackCreateViewModel(), ClientOptions()));

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind(Prefix = "Form")] FeedbackCreateViewModel model)
        {
            if (!ModelState.IsValid)
                return View("Index", new FeedbackPageViewModel(Rows(), model, ClientOptions()));

            _feedback.Add(CurrentTrainerId, model.ClientId, model.RelatedArea, model.Message, model.Rating);
            TempData["Success"] = "Feedback sent to the client.";
            return RedirectToAction(nameof(Index));
        }

        private IReadOnlyList<FeedbackRowViewModel> Rows()
        {
            var names = _clients.GetAssignedClients(CurrentTrainerId).ToDictionary(c => c.Id, c => c.FullName);
            return _feedback.GetForTrainer(CurrentTrainerId).Select(f => new FeedbackRowViewModel
            {
                ClientName = names.TryGetValue(f.ClientId, out var n) ? n : $"Client #{f.ClientId}",
                RelatedArea = f.RelatedArea,
                Message = f.Message,
                Rating = f.Rating,
                When = f.CreatedAt.ToString("MMM d, h:mm tt")
            }).ToList();
        }

        private List<SelectListItem> ClientOptions() =>
            _clients.GetAssignedClients(CurrentTrainerId)
                .Select(c => new SelectListItem(c.FullName, c.Id.ToString())).ToList();
    }

    public sealed record FeedbackPageViewModel(
        IReadOnlyList<FeedbackRowViewModel> History,
        FeedbackCreateViewModel Form,
        List<SelectListItem> Clients);
}
