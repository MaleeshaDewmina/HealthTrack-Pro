using HealthTrackPro.Web.Areas.Trainer.Models;
using HealthTrackPro.Web.Models.Enums;
using HealthTrackPro.Web.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace HealthTrackPro.Web.Areas.Trainer.Controllers
{
    public class DashboardController : TrainerControllerBase
    {
        private readonly ITrainerDashboardService _dashboard;
        public DashboardController(ITrainerDashboardService dashboard) => _dashboard = dashboard;

        public IActionResult Index()
        {
            var summary = _dashboard.Build(CurrentTrainerId, DateTime.Today);
            var vm = new TrainerDashboardViewModel
            {
                AssignedClients = summary.AssignedClientCount,
                TodayAppointments = summary.TodayAppointmentCount,
                PlansDue = summary.PlansDueForReview,
                AverageProgress = summary.AverageProgressPercent,
                ClientRows = summary.ClientRows.Select(ClientRowViewModel.From).ToList(),
                Upcoming = summary.UpcomingToday.Select(a => new UpcomingItemViewModel
                {
                    AppointmentId = a.Id,
                    Time = a.StartsAt.ToString("h:mm tt"),
                    ClientName = summary.ClientRows.FirstOrDefault(c => c.Id == a.ClientId)?.FullName ?? $"Client #{a.ClientId}",
                    Status = a.Status.ToString()
                }).ToList(),
                Notifications = summary.RecentNotifications.Select(n => new NotificationItemViewModel
                {
                    Title = n.Title,
                    Body = n.Body,
                    When = n.CreatedAt.ToString("MMM d, h:mm tt"),
                    Accent = n.Type switch
                    {
                        NotificationType.NewAppointment => "amber",
                        NotificationType.NewFeedback or NotificationType.PlanReview => "purple",
                        _ => "green"
                    }
                }).ToList()
            };
            return View(vm);
        }
    }
}
