using HealthTrackPro.Web.Areas.Trainer.Models;
using HealthTrackPro.Web.Models.Shared;
using HealthTrackPro.Web.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace HealthTrackPro.Web.Areas.Trainer.Controllers
{
    public class PlansController : TrainerControllerBase
    {
        private readonly IPlanAssignmentService _plans;
        private readonly IAssignedClientService _clients;

        public PlansController(IPlanAssignmentService plans, IAssignedClientService clients)
        {
            _plans = plans;
            _clients = clients;
        }

        public IActionResult Index()
        {
            var names = _clients.GetAssignedClients(CurrentTrainerId).ToDictionary(c => c.Id, c => c.FullName);
            string Name(int id) => names.TryGetValue(id, out var n) ? n : $"Client #{id}";

            var vm = new PlansOverviewViewModel
            {
                Workouts = _plans.GetWorkoutPlans(CurrentTrainerId).Select(p => new PlanRowViewModel
                {
                    ClientName = Name(p.ClientId),
                    PlanName = p.Name,
                    Detail = $"{p.Exercises.Count} exercises - {p.StartDate:MMM d} to {p.EndDate:MMM d}"
                }).ToList(),
                Diets = _plans.GetDietPlans(CurrentTrainerId).Select(p => new PlanRowViewModel
                {
                    ClientName = Name(p.ClientId),
                    PlanName = p.Name,
                    Detail = $"{p.CalorieTarget} kcal - P {p.ProteinGrams}g / C {p.CarbsGrams}g / F {p.FatGrams}g"
                }).ToList()
            };
            return View(vm);
        }

        [HttpGet]
        public IActionResult AssignWorkout() => View(new AssignWorkoutViewModel());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AssignWorkout(AssignWorkoutViewModel model)
        {
            if (model.EndDate < model.StartDate)
                ModelState.AddModelError(nameof(model.EndDate), "End date cannot be before the start date.");

            if (!ModelState.IsValid)
                return View(model);

            var exercises = model.Exercises.Select(e => new WorkoutExercise
            {
                Name = e.Name, Sets = e.Sets, Reps = e.Reps, RestSeconds = e.RestSeconds
            });
            _plans.AssignWorkout(CurrentTrainerId, model.ClientId, model.PlanName, model.StartDate, model.EndDate, exercises);
            TempData["Success"] = "Workout plan assigned.";
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult AssignDiet() => View(new AssignDietViewModel());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AssignDiet(AssignDietViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var meals = model.Meals.Select(m => new Meal
            {
                MealType = m.MealType, Name = m.Name, Kcal = m.Kcal, ProteinGrams = m.ProteinGrams
            });
            _plans.AssignDiet(CurrentTrainerId, model.ClientId, model.PlanName,
                model.CalorieTarget, model.ProteinGrams, model.CarbsGrams, model.FatGrams, meals);
            TempData["Success"] = "Diet plan assigned.";
            return RedirectToAction(nameof(Index));
        }
    }
}
