using HealthTrackPro.Web.Areas.Trainer.Models;
using HealthTrackPro.Web.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace HealthTrackPro.Web.Areas.Trainer.Controllers
{
    public class NotificationsController : TrainerControllerBase
    {
        private readonly INotificationService _notifications;
        public NotificationsController(INotificationService notifications) => _notifications = notifications;

        public IActionResult Index()
        {
            var rows = _notifications.GetForUser(CurrentTrainerId).Select(n => new NotificationItemViewModel
            {
                Id = n.Id,
                Title = n.Title,
                Body = n.Body,
                When = n.CreatedAt.ToString("MMM d, h:mm tt"),
                Accent = n.IsRead ? "muted" : "green"
            }).ToList();
            return View(rows);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult MarkRead(int id)
        {
            _notifications.MarkRead(CurrentTrainerId, id);
            return RedirectToAction(nameof(Index));
        }
    }
}
