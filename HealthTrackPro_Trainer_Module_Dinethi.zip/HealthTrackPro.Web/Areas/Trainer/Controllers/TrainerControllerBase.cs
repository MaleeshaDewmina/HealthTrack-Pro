using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthTrackPro.Web.Areas.Trainer.Controllers
{
    /// <summary>
    /// Every Trainer page inherits this: the Trainer role is enforced on the server,
    /// and the signed-in trainer id is read from the identity, never from the URL.
    /// </summary>
    [Area("Trainer")]
    [Authorize(Roles = "Trainer")]
    public abstract class TrainerControllerBase : Controller
    {
        protected string CurrentTrainerId =>
            User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? throw new InvalidOperationException("Signed-in trainer has no identifier claim.");
    }
}
