using HealthTrackPro.Web.Areas.Trainer.Models;
using HealthTrackPro.Web.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace HealthTrackPro.Web.Areas.Trainer.Controllers
{
    public class AvailabilityController : TrainerControllerBase
    {
        private readonly IAvailabilityService _availability;
        public AvailabilityController(IAvailabilityService availability) => _availability = availability;

        public IActionResult Index() => View(new AvailabilityPageViewModel(Rows(), new AvailabilityCreateViewModel()));

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add([Bind(Prefix = "Form")] AvailabilityCreateViewModel model)
        {
            if (model.End <= model.Start)
                ModelState.AddModelError("Form.End", "End time must be after the start time.");

            if (!ModelState.IsValid)
                return View("Index", new AvailabilityPageViewModel(Rows(), model));

            _availability.AddSlot(CurrentTrainerId, model.Date, model.Start, model.End);
            TempData["Success"] = "Availability slot added.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Remove(int id)
        {
            _availability.RemoveSlot(CurrentTrainerId, id);
            TempData["Success"] = "Availability slot removed.";
            return RedirectToAction(nameof(Index));
        }

        private IReadOnlyList<AvailabilityRowViewModel> Rows() =>
            _availability.GetForTrainer(CurrentTrainerId).Select(s => new AvailabilityRowViewModel
            {
                Id = s.Id,
                Date = s.Date.ToString("MMM d, yyyy"),
                Range = $"{DateTime.Today.Add(s.Start):h:mm tt} - {DateTime.Today.Add(s.End):h:mm tt}",
                Status = s.IsOpen ? "Open" : "Closed"
            }).ToList();
    }

    public sealed record AvailabilityPageViewModel(IReadOnlyList<AvailabilityRowViewModel> Slots, AvailabilityCreateViewModel Form);
}
