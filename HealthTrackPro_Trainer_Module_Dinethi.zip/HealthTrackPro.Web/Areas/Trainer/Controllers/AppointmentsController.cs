using HealthTrackPro.Web.Areas.Trainer.Models;
using HealthTrackPro.Web.Models.Enums;
using HealthTrackPro.Web.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace HealthTrackPro.Web.Areas.Trainer.Controllers
{
    public class AppointmentsController : TrainerControllerBase
    {
        private readonly IAppointmentService _appointments;
        private readonly IAssignedClientService _clients;

        public AppointmentsController(IAppointmentService appointments, IAssignedClientService clients)
        {
            _appointments = appointments;
            _clients = clients;
        }

        public IActionResult Index()
        {
            var names = _clients.GetAssignedClients(CurrentTrainerId).ToDictionary(c => c.Id, c => c.FullName);
            var rows = _appointments.GetForTrainer(CurrentTrainerId).Select(a => new AppointmentRowViewModel
            {
                Id = a.Id,
                ClientName = names.TryGetValue(a.ClientId, out var n) ? n : $"Client #{a.ClientId}",
                When = a.StartsAt.ToString("ddd, MMM d - h:mm tt"),
                Reason = a.Reason,
                Status = a.Status.ToString(),
                CanDecide = a.Status == AppointmentStatus.Pending,
                CanCancel = a.Status is AppointmentStatus.Pending or AppointmentStatus.Approved
            }).ToList();
            return View(rows);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Approve(int id)
        {
            _appointments.Approve(CurrentTrainerId, id);
            TempData["Success"] = "Appointment approved and client notified.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Reject(int id)
        {
            _appointments.Reject(CurrentTrainerId, id);
            TempData["Success"] = "Appointment declined.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Cancel(int id)
        {
            _appointments.Cancel(CurrentTrainerId, id);
            TempData["Success"] = "Appointment cancelled.";
            return RedirectToAction(nameof(Index));
        }
    }
}
