using HealthTrackPro.Web.Areas.Trainer.Models;
using HealthTrackPro.Web.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace HealthTrackPro.Web.Areas.Trainer.Controllers
{
    public class AssignedClientsController : TrainerControllerBase
    {
        private readonly IAssignedClientService _clients;
        public AssignedClientsController(IAssignedClientService clients) => _clients = clients;

        public IActionResult Index(string? search)
        {
            var rows = _clients.GetAssignedClients(CurrentTrainerId, search).Select(ClientRowViewModel.From).ToList();
            return View(new AssignedClientsViewModel { Search = search, Clients = rows });
        }

        public IActionResult Details(int id)
        {
            // Throws TrainerForbiddenException / TrainerNotFoundException for anyone not assigned.
            var c = _clients.GetAssignedClient(CurrentTrainerId, id);
            var vm = new ClientDetailsViewModel
            {
                Id = c.Id,
                Name = c.FullName,
                Goal = c.Goal,
                WeightKg = c.WeightKg,
                Bmi = c.Bmi,
                WorkoutCompletion = c.WorkoutCompletionPercent,
                GoalProgress = c.GoalProgressPercent,
                RecentProgress = c.WeightHistory
            };
            return View(vm);
        }
    }
}
