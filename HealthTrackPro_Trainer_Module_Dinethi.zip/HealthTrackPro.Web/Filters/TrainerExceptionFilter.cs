using HealthTrackPro.Web.Services.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace HealthTrackPro.Web.Filters
{
    /// <summary>
    /// Converts expected trainer errors into friendly responses instead of crashes:
    ///  - not found        -> back to the dashboard with a red message
    ///  - forbidden        -> the Access Denied page (ownership check failed)
    ///  - rule violation   -> back to the previous screen with a red message
    ///  - anything else    -> logged, generic error page
    /// </summary>
    public sealed class TrainerExceptionFilter : IExceptionFilter
    {
        private readonly ILogger<TrainerExceptionFilter> _logger;
        private readonly ITempDataDictionaryFactory _tempDataFactory;

        public TrainerExceptionFilter(ILogger<TrainerExceptionFilter> logger, ITempDataDictionaryFactory tempDataFactory)
        {
            _logger = logger;
            _tempDataFactory = tempDataFactory;
        }

        public void OnException(ExceptionContext context)
        {
            var ex = context.Exception;

            if (ex is TrainerForbiddenException)
            {
                context.Result = new RedirectToActionResult("AccessDenied", "Account", new { area = "" });
            }
            else if (ex is TrainerNotFoundException or TrainerRuleViolationException)
            {
                _tempDataFactory.GetTempData(context.HttpContext)["Error"] = ex.Message;
                context.Result = new RedirectToActionResult("Index", "Dashboard", new { area = "Trainer" });
                var referer = context.HttpContext.Request.Headers.Referer.ToString();
                if (!string.IsNullOrEmpty(referer) && ex is TrainerRuleViolationException)
                {
                    context.Result = new RedirectResult(referer);
                }
            }
            else if (ex is TrainerDomainException)
            {
                _logger.LogWarning(ex, "Trainer domain error");
                context.Result = new RedirectToActionResult("Error", "Account", new { area = "" });
            }
            else
            {
                _logger.LogError(ex, "Unhandled error in Trainer module");
                context.Result = new RedirectToActionResult("Error", "Account", new { area = "" });
            }

            context.ExceptionHandled = true;
        }
    }
}
