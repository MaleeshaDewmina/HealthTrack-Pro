using Microsoft.AspNetCore.Mvc;

namespace HealthTrackPro.Web.Controllers
{
    /// <summary>Shared error and access pages. Login/register screens belong to Maleesha.</summary>
    public class AccountController : Controller
    {
        public IActionResult AccessDenied(string? reason = null)
        {
            ViewData["Reason"] = reason ?? "You do not have permission to open this page.";
            return View();
        }

        public IActionResult Error() => View();
    }
}
