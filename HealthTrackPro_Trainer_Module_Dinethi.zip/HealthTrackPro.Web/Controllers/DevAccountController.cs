using System.Security.Claims;
using HealthTrackPro.Web.Services.Implementations;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;

namespace HealthTrackPro.Web.Controllers
{
    /// <summary>
    /// DEVELOPMENT ONLY stand-in for the team's ASP.NET Identity login (owner: Maleesha).
    /// It signs in the Trainer account used for demos. Disabled outside Development.
    /// </summary>
    public class DevAccountController : Controller
    {
        private readonly IWebHostEnvironment _env;
        public DevAccountController(IWebHostEnvironment env) => _env = env;

        [HttpGet]
        public IActionResult SignIn()
        {
            if (!_env.IsDevelopment()) return NotFound();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SignIn(string role)
        {
            if (!_env.IsDevelopment()) return NotFound();

            // Only the trainer account is wired up in this module.
            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, InMemoryTrainerStore.DinethiTrainerId),
                new(ClaimTypes.Name, "Dinethi Ruvisha"),
                new(ClaimTypes.Role, "Trainer")
            };
            var identity = new ClaimsIdentity(claims, "HealthTrackCookie");
            await HttpContext.SignInAsync("HealthTrackCookie", new ClaimsPrincipal(identity));
            return RedirectToAction("Index", "Dashboard", new { area = "Trainer" });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync("HealthTrackCookie");
            return RedirectToAction(nameof(SignIn));
        }
    }
}
